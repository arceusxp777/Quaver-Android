# BASS / BASS_FX para Android (arm64-v8a) — SOLO DESARROLLO

Origen: repo de terceros `basslib-android` (grupo `com.github.rockmyworld`, jitpack), aportado por el usuario.
Contenido verificado localmente: ELF aarch64 reales; cabeceras Java de "BASS 2.4 ... Un4seen Developments 1999-2021";
BASS_FX 2.4.12; exportan los simbolos que usa ManagedBass (BASS_Init, BASS_ChannelGetPosition, BASS_FX_TempoCreate...);
alineacion de segmentos 16 KB (0x4000).

NO verificado: que sean identicos a los paquetes oficiales de https://www.un4seen.com (sin red para comparar hashes) y
que su redistribucion este permitida (el repo de origen no incluye licencia). BASS es gratis solo para uso no comercial.

Antes de publicar cualquier APK: sustituir por los binarios del paquete oficial de un4seen, comparar y revisar su licencia.
No se incluye libbass_aac.so (no la usa el codigo de Quaver/Wobble; se evaluara si hace falta decodificar AAC).
